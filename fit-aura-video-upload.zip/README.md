# Fit Aura Intro Video

This repo contains a video for embedding in your fitness app.
